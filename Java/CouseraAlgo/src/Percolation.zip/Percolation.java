import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private WeightedQuickUnionUF link;
    private int[] lst;
    private int num;
    private int openSites;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        link = new WeightedQuickUnionUF(n*n + 2);
        lst = new int[n*n];
        num = n;
        openSites = 0;

        for (int i = 0; i < n; i++) {
            // initiallizing lst {0,1}
            lst[i] = 0;

            // linking imagery nodes to first and last rows
            link.union(n*n, i); // top imagery node
            link.union(n*n + 1, n*(n-1) + i); // bottom imagery node
        }
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        int curNum = row*num + col;
        if (isFull(row, col)) {
            // opening (row,col) in list with {0,1}
            lst[curNum] = 1;
            openSites += 1;
            
            // linking (row,col) with opened sites on UDLR
            if ((curNum+1)/num == row && curNum+1 < num*num) if (lst[curNum+1] == 1) link.union(curNum, curNum+1); // doesn't exceed the row && be less than N*N
            if ((curNum-1)/num == row && curNum-1 >= 0) if (lst[curNum-1] == 1) link.union(curNum, curNum-1); // doesn't exceed the row && be >= 0
            if (curNum+num < num*num) if (lst[curNum+num] == 1) link.union(curNum, curNum+num);
            if (curNum-num >= 0) if (lst[curNum-num] == 1) link.union(curNum, curNum-num);
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        return lst[row*num+col] == 1;
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        return lst[row*num+col] == 0;
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return openSites;
    }

    // does the system percolate?
    public boolean percolates() {
        return link.find(num*num) == link.find(num*num+1);
    }

    // test client (optional)
    public static void main(String[] args) {

    }
}
